package com.example.pranto.setplane;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    EditText editText;
    ImageButton button;
    Spinner spinner;
    Button Developer,Association,Map;
    A a;
    B bb;
    C c;
    H h;
    I i;

    TextView textView,link2,textView1;
    String Unit;
    String ROLL,ROOM,BUILDING,INSTITUTION,EXAMTIME;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText = findViewById(R.id.edittext);
        button = findViewById(R.id.button);
        spinner = findViewById(R.id.sp);
        textView = findViewById(R.id.textview);
        textView1 = findViewById(R.id.textView1);
        Developer =findViewById(R.id.Developer);
        Association = findViewById(R.id.Association);
        Map = findViewById(R.id.Map);

        a = new A();
        bb = new B();
        c = new C();
        h = new H();
        i = new I();

        link2 = findViewById(R.id.link2);
        link2.setMovementMethod(LinkMovementMethod.getInstance());

        Developer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,Developer.class);
                startActivity(intent);
            }
        });
        Association.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,Association2.class);
                startActivity(intent); }});
        Map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,ExamMap.class);
                startActivity(intent);
            }
        });

        final String[] unit = {"Select Unit","          A","          B","          C","          H","           I"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,unit);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i)
                {
                    case 0:
                        Unit = "Select Unit";
                        textView1.setText("");
                        break;
                    case 1:
                    { Unit = "A";
                        textView1.setText("A");
                        break;}
                    case 2:
                    {Unit = "B";
                        textView1.setText("B");
                        break;}
                    case 3:
                    {Unit = "C";
                        textView1.setText("C");
                        break;}
                    case 4:
                    {Unit = "H";
                        textView1.setText("H");
                        break;}
                    case 5:
                    {Unit = "I";
                        textView1.setText("I");
                        break;}
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int roll=0;
                String s = editText.getText().toString().trim();
                if(s.length()!=0)
                    roll = Integer.parseInt(editText.getText().toString());

                if(Unit=="Select Unit"){
                    textView.setTextColor(Color.RED);
                    textView.setText("Please Select Unit");
                }
                // A Unit
                else if (Unit == "A"){
                    boolean b = ckpass(s,00001,19986,Unit,roll);
                    if(b==true){
                        textView.setTextColor(Color.BLACK);
                        editText.setText("");
                        ROLL = "Roll : "+Unit+s;
                        EXAMTIME = "Exam Time : 10/11/2018; 3:30 PM";
                        INSTITUTION = "Center : "+ a.findDInstitution(roll);
                        ROOM = "Room No : "+ a.findDRoom(roll);
                        BUILDING = "Location : "+ a.findDBuilding(roll);
                        textView.setText(""+ROLL+"\n"+EXAMTIME+"\n"+ROOM+"\n"+BUILDING+"\n"+INSTITUTION);
                    }
                }
                // B Unit
                else if (Unit == "B"){

                    boolean b = ckpass(s,00001,11500,Unit,roll);
                    if(b==true){
                        textView.setTextColor(Color.BLACK);
                        editText.setText("");
                        ROLL = "Roll : "+Unit+s;
                        EXAMTIME = "Exam Time : 10/11/2018; 1:00 PM";
                        INSTITUTION = "Center : "+ bb.findInstitution(roll);
                        ROOM = "Room No : "+ bb.findERoom(roll);
                        BUILDING = "Location : "+ bb.findEBuilding(roll);
                        textView.setText(""+ROLL+"\n"+EXAMTIME+"\n"+ROOM+"\n"+BUILDING+"\n"+INSTITUTION);
                    }
                }
                // C unit
                else if (Unit == "C"){
                    boolean b = ckpass(s,00001,15500,Unit,roll);
                    if(b==true){
                        textView.setTextColor(Color.BLACK);
                        editText.setText("");
                        ROLL = "Roll : "+Unit+s;
                        EXAMTIME = "Exam Time : 9/11/2018; 10:00 AM";
                        INSTITUTION = "Center : "+ c.findFInstitution(roll);
                        ROOM = "Room No : "+ c.findFRoom(roll);
                        BUILDING = "Location : "+ c.findFBuilding(roll);
                        textView.setText(""+ROLL+"\n"+EXAMTIME+"\n"+ROOM+"\n"+BUILDING+"\n"+INSTITUTION);
                    }
                }
                // H Unit
                else if (Unit == "H"){
                    boolean b = ckpass(s,00001,8998,Unit,roll);
                    if(b==true){
                        textView.setTextColor(Color.BLACK);
                        editText.setText("");
                        ROLL = "Roll : "+Unit+s;
                        EXAMTIME = "Exam Time : 9/11/2018; 3:00 PM";
                        INSTITUTION = "Center : "+ h.findGInstitution(roll);
                        ROOM = "Room No : "+ h.findGRoom(roll);
                        BUILDING = "Location : "+ h.findGBuilding(roll);
                        textView.setText(""+ROLL+"\n"+EXAMTIME+"\n"+ROOM+"\n"+BUILDING+"\n"+INSTITUTION);
                    }
                }
                //I Unit
                else if (Unit == "I"){
                    boolean b = ckpass(s,00001,1000,Unit,roll);
                    if(b==true){
                        textView.setTextColor(Color.BLACK);
                        editText.setText("");
                        ROLL = "Roll : "+Unit+s;
                        EXAMTIME = "Exam Time : 10/11/2018; 10:00 AM";
                        INSTITUTION = "Center : "+i.findGInstitution(roll);
                        ROOM = "Room No : "+i.findGRoom(roll);
                        BUILDING = "Location : "+i.findGBuilding(roll);
                        textView.setText(""+ROLL+"\n"+EXAMTIME+"\n"+ROOM+"\n"+BUILDING+"\n"+INSTITUTION);
                    }
                }
            }
        });
    }
    private boolean ckpass(String  pass, int low,int up,String unit,int roll) {
        if(pass.length()==0){
            textView.setTextColor(Color.RED);
            textView.setText("Roll is not Empty\nPlease Enter Valid Roll.");
            return false;
        }
        else if(pass.length()<5||pass.length()>5)
        {
            int ln = pass.length();
            textView.setTextColor(Color.RED);
            textView.setText("Roll can't be "+ln+" Digit\nPlease Enter Exact 5 Digits Roll Number");
            return false;
        }
        else if(roll>up||roll<low)
        {
            textView.setTextColor(Color.RED);
            textView.setText(""+unit+" Unit Roll Range: "+low+" - "+up+"\nPlease Enter Right Roll");
            return false;
        }

        return true;
    }
}






