package com.example.pranto.setplane;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.ZoomControls;

public class ExamMap extends AppCompatActivity {
     LinearLayout map;
     ImageView image;
     ZoomControls zoom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exam_map);
        setTitle("Seat Plan Map");
        image = (ImageView)findViewById(R.id.map);
        zoom=(ZoomControls)findViewById(R.id.zoomcontrol);
        zoom.hide();
    /*    image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                zoom.show();
                return;
            }
        });
        zoom.setOnZoomInClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float x = image.getScaleX();
                float y = image.getScaleY();
                image.setScaleX((float)(x+1));
                image.setScaleY((float)(y+1));
                zoom.hide();
            }
        });
        zoom.setOnZoomOutClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float x = image.getScaleX();
                float y = image.getScaleY();
                image.setScaleX((float)(x-1));
                image.setScaleY((float)(y-1));
                zoom.hide();
            }
        });*/
    }
}
