package com.example.pranto.setplane;

public class B {
   String findInstitution (int roll){
       String institution = "";
       if(roll>=1&&roll<=8201)
       {
           institution="BSMRSTU";
       }
     else  if(roll>=8202&&roll<=10869)
       {
           institution="Govt. Bangabandhu College, Gopalganj";
       }
      else if(roll>=10870&&roll<=11500)
       {
           institution="Gopalganj Girls High School";
       }
       return institution;
   }
   String findERoom(int roll){
       String room = "";
       if(roll>=00001&&roll<=00165)
       {
           room="Bank Varanda (Ground floor)";
       }
     else  if(roll>=166&&roll<=330)
       {
           room="Faculty Varanda (Ground floor)";
       }
       else  if(roll>=331&&roll<=410)
       {
           room="215";
       } else  if(roll>=411&&roll<=490)
       {
           room="303";
       } else  if(roll>=491&&roll<=540)
       {
           room="308";
       } else  if(roll>=541&&roll<=620)
       {
           room="403";
       } else  if(roll>=621&&roll<=670)
       {
           room="408";
       } else  if(roll>=671&&roll<=740)
       {
           room="413";
       } else  if(roll>=741&&roll<=770)
       {
           room="414";
       } else  if(roll>=771&&roll<=820)
       {
           room="416";
       } else  if(roll>=821&&roll<=890)
       {
           room="503";
       } else  if(roll>=891&&roll<=935)
       {
           room="504";
       } else  if(roll>=936&&roll<=975)
       {
           room="506";
       } else  if(roll>=976&&roll<=1055)
       {
           room="513";
       } else  if(roll>=1056&&roll<=1100)
       {
           room="516";
       } else  if(roll>=1101&&roll<=1230)
       {
           room="Varanda (Ground floor), infront of Pharmacy Lab";
       } else  if(roll>=1231&&roll<=1315)
       {
           room="103";
       } else  if(roll>=1316&&roll<=1410)
       {
           room="104";
       } else  if(roll>=1411&&roll<=1455)
       {
           room="201";
       } else  if(roll>=1456&&roll<=1535)
       {
           room="202";
       } else  if(roll>=1536&&roll<=1615)
       {
           room="203";
       } else  if(roll>=1616&&roll<=1670)
       {
           room="205";
       } else  if(roll>=1671&&roll<=1715)
       {
           room="209";
       } else  if(roll>=1716&&roll<=1750)
       {
           room="302";
       } else  if(roll>=1751&&roll<=1870)
       {
           room="307";
       } else  if(roll>=1871&&roll<=1930)
       {
           room="308";
       } else  if(roll>=1931&&roll<=1960)
       {
           room="311";
       } else  if(roll>=1961&&roll<=2050)
       {
           room="312";
       } else  if(roll>=2051&&roll<=2105)
       {
           room="401(B)";
       } else  if(roll>=2106&&roll<=2175)
       {
           room="407(B)";
       } else  if(roll>=2176&&roll<=2270)
       {
           room="408";
       } else  if(roll>=2271&&roll<=2325)
       {
           room="506";
       } else  if(roll>=2326&&roll<=2390)
       {
           room="507";
       } else  if(roll>=2391&&roll<=2450)
       {
           room="508";
       } else  if(roll>=2451&&roll<=2510)
       {
           room="511";
       } else  if(roll>=2511&&roll<=2600)
       {
           room="512";
       } else  if(roll>=2601&&roll<=2790)
       {
           room="101, Hall Room";
       } else  if(roll>=2791&&roll<=2980)
       {
           room="102, Hall Room";
       } else  if(roll>=2981&&roll<=3040)
       {
           room="103";
       } else  if(roll>=3041&&roll<=3100)
       {
           room="104";
       } else  if(roll>=3101&&roll<=3160)
       {
           room="105";
       } else  if(roll>=3161&&roll<=3220)
       {
           room="106";
       } else  if(roll>=3221&&roll<=3280)
       {
           room="107";
       } else  if(roll>=3281&&roll<=3370)
       {
           room="108";
       } else  if(roll>=3371&&roll<=3430)
       {
           room="201";
       } else  if(roll>=3431&&roll<=3490)
       {
           room="202";
       } else  if(roll>=3491&&roll<=3550)
       {
           room="203";
       } else  if(roll>=3551&&roll<=3610)
       {
           room="204";
       } else  if(roll>=3611&&roll<=3671)
       {
           room="205";
       } else  if(roll>=3672&&roll<=3761)
       {
           room="206";
       } else  if(roll>=3762&&roll<=3851)
       {
           room="207";
       } else  if(roll>=3852&&roll<=3941)
       {
           room="208";
       } else  if(roll>=3942&&roll<=4031)
       {
           room="209";
       } else  if(roll>=4032&&roll<=4091)
       {
           room="301";
       } else  if(roll>=4092&&roll<=4151)
       {
           room="302";
       } else  if(roll>=4152&&roll<=4211)
       {
           room="303";
       } else  if(roll>=4212&&roll<=04271)
       {
           room="304";
       } else  if(roll>=4272&&roll<=4331)
       {
           room="305";
       } else  if(roll>=4332&&roll<=4391)
       {
           room="306";
       } else  if(roll>=4392&&roll<=4481)
       {
           room="307";
       } else  if(roll>=4482&&roll<=4571)
       {
           room="308";
       } else  if(roll>=4572&&roll<=4661)
       {
           room="309";
       } else  if(roll>=4662&&roll<=4751)
       {
           room="310";
       } else  if(roll>=4752&&roll<=4841)
       {
           room="401";
       } else  if(roll>=4842&&roll<=4931)
       {
           room="402";
       } else  if(roll>=4932&&roll<=5021)
       {
           room="403";
       } else  if(roll>=5022&&roll<=5111)
       {
           room="404";
       } else  if(roll>=5112&&roll<=5201)
       {
           room="405";
       } else  if(roll>=5202&&roll<=5291)
       {
           room="406";
       } else  if(roll>=5292&&roll<=5381)
       {
           room="407";
       } else  if(roll>=5382&&roll<=5471)
       {
           room="408";
       } else  if(roll>=5472&&roll<=5561)
       {
           room="501";
       } else  if(roll>=5562&&roll<=5651)
       {
           room="502";
       } else  if(roll>=5652&&roll<=5841)
       {
           room="503,Hall Room";
       } else  if(roll>=5842&&roll<=5931)
       {
           room="Computer Browsing Lab";
       } else  if(roll>=5932&&roll<=6041)
       {
           room="Library Ground Open Space";
       } else  if(roll>=6042&&roll<=6181)
       {
           room="Library 1st Floor Reading Room";
       } else  if(roll>=6182&&roll<=6731)
       {
           room="Garage";
       } else  if(roll>=6732&&roll<=6821)
       {
           room="101";
       } else  if(roll>=6822&&roll<=6911)
       {
           room="102";
       } else  if(roll>=6912&&roll<=7001)
       {
           room="103";
       } else  if(roll>=7002&&roll<=7071)
       {
           room="104";
       } else  if(roll>=7072&&roll<=7141)
       {
           room="105";
       } else  if(roll>=7142&&roll<=7221)
       {
           room="106";
       } else  if(roll>=7222&&roll<=7281)
       {
           room="107";
       } else  if(roll>=7282&&roll<=7371)
       {
           room="108";
       } else  if(roll>=7372&&roll<=7461)
       {
           room="109";
       } else  if(roll>=7462&&roll<=7661)
       {
           room="Hall Room";
       } else  if(roll>=7662&&roll<=7751)
       {
           room="101";
       } else  if(roll>=7752&&roll<=7841)
       {
           room="102";
       } else  if(roll>=7842&&roll<=7881)
       {
           room="103";
       } else  if(roll>=7882&&roll<=7921)
       {
           room="104";
       } else  if(roll>=7922&&roll<=7961)
       {
           room="105";
       } else  if(roll>=7962&&roll<=8001)
       {
           room="106";
       } else  if(roll>=8002&&roll<=8041)
       {
           room="107";
       } else  if(roll>=8042&&roll<=8081)
       {
           room="108";
       } else  if(roll>=8082&&roll<=8121)
       {
           room="109";
       } else  if(roll>=8122&&roll<=8161)
       {
           room="110";
       } else  if(roll>=8162&&roll<=8201)
       {
           room="111";
       } else  if(roll>=8202&&roll<=8372)
       {
           room="1001";
       } else  if(roll>=8373&&roll<=8543)
       {
           room="1002";
       } else  if(roll>=8544&&roll<=8643)
       {
           room="2001";
       } else  if(roll>=8644&&roll<=8743)
       {
           room="2002";
       } else  if(roll>=8744&&roll<=8838)
       {
           room="2003";
       } else  if(roll>=8839&&roll<=8928)
       {
           room="2004";
       } else  if(roll>=8929&&roll<=9018)
       {
           room="3001";
       } else  if(roll>=9019&&roll<=9093)
       {
           room="3004";
       } else  if(roll>=9094&&roll<=9155)
       {
           room="4001";
       } else  if(roll>=9156&&roll<=9205)
       {
           room="4004";
       } else  if(roll>=9206&&roll<=9376)
       {
           room="5001";
       } else  if(roll>=9377&&roll<=9466)
       {
           room="102";
       } else  if(roll>=9467&&roll<=9528)
       {
           room="104";
       } else  if(roll>=9529&&roll<=9618)
       {
           room="105";
       } else  if(roll>=9619&&roll<=9708)
       {
           room="106";
       } else  if(roll>=9709&&roll<=9803)
       {
           room="202";
       } else  if(roll>=9804&&roll<=9868)
       {
           room="203";
       } else  if(roll>=9869&&roll<=9958)
       {
           room="205";
       } else  if(roll>=9959&&roll<=10048)
       {
           room="206";
       } else  if(roll>=10049&&roll<=10118)
       {
           room="302";
       } else  if(roll>=10119&&roll<=10208)
       {
           room="303";
       } else  if(roll>=10209&&roll<=10298)
       {
           room="305";
       } else  if(roll>=10299&&roll<=10393)
       {
           room="306";
       } else  if(roll>=10394&&roll<=10453)
       {
           room="402";
       } else  if(roll>=10454&&roll<=10589)
       {
           room="403";
       } else  if(roll>=10590&&roll<=10684)
       {
           room="405";
       } else  if(roll>=10685&&roll<=10779)
       {
           room="406";
       } else  if(roll>=10780&&roll<=10869)
       {
           room="Girl's Common Room";
       } else  if(roll>=10870&&roll<=10937)
       {
           room="101";
       } else  if(roll>=10938&&roll<=10982)
       {
           room="102";
       } else  if(roll>=10983&&roll<=11078)
       {
           room="103";
       } else  if(roll>=11079&&roll<=11173)
       {
           room="104";
       } else  if(roll>=11175&&roll<=11284)
       {
           room="105";
       } else  if(roll>=11285&&roll<=11348)
       {
           room="106";
       } else  if(roll>=11349&&roll<=11397)
       {
           room="107";
       } else  if(roll>=11398&&roll<=11447)
       {
           room="208";
       } else  if(roll>=11449&&roll<=11500)
       {
           room="209";
       }
       return  room;
   }
   String findEBuilding (int roll){
       String  building = "";
       if(roll>=1 &&roll<=1100)
       {
           building="Administr ative Building";
       }
       else if(roll>=1101 &&roll<=2600)
       {
           building="Academic Building";
       } else if(roll>=2601 &&roll<=5841)
       {
           building="Academic Building (New)";
       } else if(roll>=5842 &&roll<=6181)
       {
           building="Library";
       } else if(roll>=6182 &&roll<=6731)
       {
           building="University Garage";
       } else if(roll>=6732 &&roll<=7141)
       {
           building="Bangabandhu University School & College (Tin Shed 1: Near Library)";
       } else if(roll>=7142 &&roll<=7461)
       {
           building="Bangaban dhu University School & College (Tin Shed 2: Near Library)";
       }else if(roll>=7462 &&roll<=8201)
       {
           building="Bangabandhu University School & College (Near VC`s Residence)";
       }
       return building;
   }
}