package com.example.pranto.setplane;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

public class Developer extends AppCompatActivity {
    TextView rab,pra,sak,sag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_developer);
        setTitle("Developer Team");

        rab = findViewById(R.id.rab);
        pra = findViewById(R.id.pra);
        sak = findViewById(R.id.sak);
        sag =findViewById(R.id.sag);

        rab.setMovementMethod(LinkMovementMethod.getInstance());
        pra.setMovementMethod(LinkMovementMethod.getInstance());
        sak.setMovementMethod(LinkMovementMethod.getInstance());
        sag.setMovementMethod(LinkMovementMethod.getInstance());
    }
}
