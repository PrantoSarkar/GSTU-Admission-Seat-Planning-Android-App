package com.example.pranto.setplane;

public  class C {

    String findFInstitution(int roll){
        String institution = "";
        if(roll>=1&&roll<=8201){
            institution = "BSMRSTU";
        }
        else  if(roll>=8202&&roll<=10871){
            institution = "Govt. Bangabandhu College, Gopalganj";
        }
        else  if(roll>=10872&&roll<=12171){
            institution = "Sheikh Hasina Govt. Girls High School, Gopalganj";
        }else  if(roll>=12172&&roll<=13477){
            institution = "Sheikh Fazilatun-nesa Govt. Mohila College,Gopalganj";
        }else  if(roll>=13478&&roll<=13941){
            institution = "Gopalganj Girls High School";
        }else  if(roll>=13942&&roll<=15500){
            institution = "Hazi Lal Mia City College, Gopalganj";
        }
        return institution;
    }
    String findFRoom(int roll){
        String room = "";
        if(roll>=1&&roll<=165)
        {
            room = "Bank Varanda (Ground floor)";
        }
        else if(roll>=166&&roll<=330)
        {
            room = "Faculty Varanda (Ground floor)";
        }
        else if(roll>=331&&roll<=410)
        {
            room = "215";
        }
        else if(roll>=411&&roll<=490)
        {
            room = "303";
        }
        else if(roll>=491&&roll<=540)
        {
            room = "308";
        }
        else if(roll>=541&&roll<=620)
        {
            room = "403";
        }
        else if(roll>=621&&roll<=670)
        {
            room = "408";
        }
        else if(roll>=671&&roll<=740)
        {
            room = "413";
        }
        else if(roll>=741&&roll<=770)
        {
            room = "414";
        }
        else if(roll>=771&&roll<=820)
        {
            room = "416";
        }
        else if(roll>=821&&roll<=890)
        {
            room = "503";
        }
        else if(roll>=891&&roll<=935)
        {
            room = "504";
        }
        else if(roll>=936&&roll<=975)
        {
            room = "506";
        }
        else if(roll>=976&&roll<=1055)
        {
            room = "513";
        }
        else if(roll>=1056&&roll<=1100)
        {
            room = "516";
        }

        //Academic Building
        else if(roll>=1101&&roll<=1230)
        {
            room = "Varanda (Ground floor), infront of Pharmacy Lab";
        }
        else if(roll>=1231&&roll<=1315)
        {
            room = "103";
        }
        else if(roll>=1316&&roll<=1410)
        {
            room = "104";
        }
        else if(roll>=1411&&roll<=1455)
        {
            room = "201";
        }
        else if(roll>=1456&&roll<=1535)
        {
            room = "202";
        }
        else if(roll>=1536&&roll<=1615)
        {
            room = "203";
        }
        else if(roll>=1616&&roll<=1670)
        {
            room = "205";
        }
        else if(roll>=1671&&roll<=1715)
        {
            room = "209";
        }
        else if(roll>=1716&&roll<=1750)
        {
            room = "302";
        }
        else if(roll>=1751&&roll<=1870)
        {
            room = "307";
        }
        else if(roll>=1871&&roll<=1930)
        {
            room = "308";
        }
        else if(roll>=1931&&roll<=1960)
        {
            room = "311";
        }
        else if(roll>=1961&&roll<=2050)
        {
            room = "312";
        }
        else if(roll>=2051&&roll<=2105)
        {
            room = "401(B)";
        }
        else if(roll>=2106&&roll<=2175)
        {
            room = "407(B)";
        }
        else if(roll>=2176&&roll<=2270)
        {
            room = "408";
        }
        else if(roll>=2271&&roll<=2325)
        {
            room = "506";
        }
        else if(roll>=2326&&roll<=2390)
        {
            room = "507";
        }
        else if(roll>=2391&&roll<=2450)
        {
            room = "508";
        }
        else if(roll>=2451&&roll<=2510)
        {
            room = "511";
        }
        else if(roll>=2511&&roll<=2600)
        {
            room = "512";
        }
//Academic Building (New)

        else if(roll>=2601&&roll<=2790)
        {
            room = "101, Hall Room";
        }
        else if(roll>=2791&&roll<=2980)
        {
            room = "102, Hall Room";
        }
        else if(roll>=2981&&roll<=3040)
        {
            room = "103";
        }
        else if(roll>=3041&&roll<=3100)
        {
            room = "104";
        }
        else if(roll>=3101&&roll<=3160)
        {
            room = "105";
        }
        else if(roll>=3161&&roll<=3220)
        {
            room = "106";
        }
        else if(roll>=3221&&roll<=3281)
        {
            room = "107";
        }

        else if(roll>=3282&&roll<=3371)
        {
            room = "108";
        }
        else if(roll>=3372&&roll<=3431)
        {
            room = "201";
        }
        else if(roll>=3432&&roll<=3491)
        {
            room = "202";
        }
        else if(roll>=3492&&roll<=3551)
        {
            room = "203";
        }
        else if(roll>=3552&&roll<=3611)
        {
            room = "204";
        }
        else if(roll>=3612&&roll<=3671)
        {
            room = "205";
        }
        else if(roll>=3672&&roll<=3761)
        {
            room = "206";
        }
        else if(roll>=3762&&roll<=3851)
        {
            room = "207";
        }
        else if(roll>=3852&&roll<=3941)
        {
            room = "208";
        }
        else if(roll>=3942&&roll<=4031)
        {
            room = "209";
        }
        else if(roll>=4032&&roll<=4091)
        {
            room = "301";
        }
        else if(roll>=4092&&roll<=4151)
        {
            room = "302";
        }
        else if(roll>=4152&&roll<=4211)
        {
            room = "303";
        }
        else if(roll>=4212&&roll<=4271)
        {
            room = "304";
        }
        else if(roll>=4272&&roll<=4331)
        {
            room = "305";
        }
        else if(roll>=4332&&roll<=4391)
        {
            room = "306";
        }
        else if(roll>=4392&&roll<=4481)
        {
            room = "307";
        }
        else if(roll>=4482&&roll<=4571)
        {
            room = "308";
        }
        else if(roll>=4572&&roll<=4661)
        {
            room = "309";
        }
        else if(roll>=4662&&roll<=4751)
        {
            room = "310";
        }
        else if(roll>=4752&&roll<=4841)
        {
            room = "401";
        }
        else if(roll>=4842&&roll<=4931)
        {
            room = "402";
        }
        else if(roll>=4932&&roll<=5021)
        {
            room = "403";
        }

        else if(roll>=5022&&roll<=5111)
        {
            room = "404";
        }
        else if(roll>=5112&&roll<=5201)
        {
            room = "405";
        }
        else if(roll>=5202&&roll<=5291)
        {
            room = "406";
        }
        else if(roll>=5292&&roll<=5381)
        {
            room = "407";
        }
        else if(roll>=5382&&roll<=5471)
        {
            room = "408";
        }
        else if(roll>=5472&&roll<=5561)
        {
            room = "501";
        }
        else if(roll>=5562&&roll<=5651)
        {
            room = "502";
        }
        else if(roll>=5652&&roll<=5841)
        {
            room = "503,Hall Room";
        }

        //Library
        else if(roll>=5842&&roll<=5931)
        {
            room = "Computer Browsing Lab";
        }
        else if(roll>=5932&&roll<=6041)
        {
            room = "Library Ground Open Space";
        }
        else if(roll>=6042&&roll<=6181)
        {
            room = "Library 1st Floor Reading Room";
        }

        //University Garage
        else if(roll>=6182&&roll<=6731)
        {
            room = "Garage";
        }
        //Tin Shed 1
        else if(roll>=6732&&roll<=6821)
        {
            room = "101";
        }
        else if(roll>=6822&&roll<=6911)
        {
            room = "102";
        }
        else if(roll>=6912&&roll<=7001)
        {
            room = "103";
        }
        else if(roll>=7002&&roll<=7071)
        {
            room = "104";
        }
        else if(roll>=7072&&roll<=7141)
        {
            room = "105";
        }

        //Tin Shed 2
        else if(roll>=7142&&roll<=7221)
        {
            room = "106";
        }
        else if(roll>=7222&&roll<=7281)
        {
            room = "107";
        }
        else if(roll>=7282&&roll<=7371)
        {
            room = "108";
        }
        else if(roll>=7372&&roll<=7461)
        {
            room = "109";
        }

        //VC
        else if(roll>=7462&&roll<=7661)
        {
            room = "Hall Room";
        }
        else if(roll>=7662&&roll<=7751)
        {
            room = "101";
        }
        else if(roll>=7752&&roll<=7841)
        {
            room = "102";
        }
        else if(roll>=7842&&roll<=7881)
        {
            room = "103";
        }
        else if(roll>=7882&&roll<=7921)
        {
            room = "104";
        }
        else if(roll>=7922&&roll<=7961)
        {
            room = "105";
        }
        else if(roll>=7962&&roll<=8001)
        {
            room = "106";
        }
        else if(roll>=8002&&roll<=8041)
        {
            room = "107";
        }
        else if(roll>=8042&&roll<=8081)
        {
            room = "108";
        }
        else if(roll>=8082&&roll<=8121)
        {
            room = "109";
        }
        else if(roll>=8122&&roll<=8161)
        {
            room = "110";
        }
        else if(roll>=8162&&roll<=8201)
        {
            room = "111";
        }

        //Govt. Bangabandhu College, Gopalganj
        else if(roll>=8202&&roll<=8372)
        {
            room = "1001";
        }
        else if(roll>=8373&&roll<=8543)
        {
            room = "1002";
        }
        else if(roll>=8544&&roll<=8643)
        {
            room = "2001";
        }
        else if(roll>=8644&&roll<=8743)
        {
            room = "2002";
        }
        else if(roll>=8744&&roll<=8838)
        {
            room = "2003";
        }
        else if(roll>=8839&&roll<=8928)
        {
            room = "2004";
        }
        else if(roll>=8929&&roll<=9018)
        {
            room = "3001";
        }
        else if(roll>=9019&&roll<=9093)
        {
            room = "3004";
        }
        else if(roll>=9094&&roll<=9155)
        {
            room = "4001";
        }
        else if(roll>=9156&&roll<=9205)
        {
            room = "4004";
        }
        else if(roll>=9206&&roll<=9377)
        {
            room = "5001";
        }
        else if(roll>=9378&&roll<=9467)
        {
            room = "102";
        }
        else if(roll>=9468&&roll<=9529)
        {
            room = "104";
        }
        else if(roll>=9530&&roll<=9619)
        {
            room = "105";
        }
        else if(roll>=9620&&roll<=9710)
        {
            room = "106";
        }
        else if(roll>=9711&&roll<=9805)
        {
            room = "202";
        }
        else if(roll>=9806&&roll<=9870)
        {
            room = "203";
        }
        else if(roll>=9871&&roll<=9960)
        {
            room = "205";
        }
        else if(roll>=9961&&roll<=10050)
        {
            room = "206";
        }
        else if(roll>=10051&&roll<=10120)
        {
            room = "302";
        }
        else if(roll>=10121&&roll<=10210)
        {
            room = "303";
        }
        else if(roll>=10211&&roll<=10300)
        {
            room = "305";
        }
        else if(roll>=10301&&roll<=10396)
        {
            room = "306";
        }
        else if(roll>=10397&&roll<=10456)
        {
            room = "402";
        }
        else if(roll>=10457&&roll<=10591)
        {
            room = "403";
        }
        else if(roll>=10592&&roll<=10686)
        {
            room = "405";
        }
        else if(roll>=10687&&roll<=10781)
        {
            room = "406";
        }
        else if(roll>=10782&&roll<=10871)
        {
            room = "Girl's Common Room";
        }
        else if(roll>=10872&&roll<=10936)
        {
            room = "101";
        }

        else if(roll>=10937&&roll<=11001)
        {
            room = "102";
        }
        else if(roll>=11002&&roll<=11066)
        {
            room = "103";
        }
        else if(roll>=11067&&roll<=11196)
        {
            room = "104";
        }
        else if(roll>=11197&&roll<=11261)
        {
            room = "201";
        }
        else if(roll>=11262&&roll<=11326)
        {
            room = "202";
        }
        else if(roll>=11327&&roll<=11391)
        {
            room = "203";
        }
        else if(roll>=11392&&roll<=11456)
        {
            room = "204";
        }
        else if(roll>=11457&&roll<=11521)
        {
            room = "205";
        }
        else if(roll>=11522&&roll<=11586)
        {
            room = "206";
        }
        else if(roll>=11587&&roll<=11651)
        {
            room = "301";
        }
        else if(roll>=11652&&roll<=11716)
        {
            room = "302";
        }
        else if(roll>=11717&&roll<=11781)
        {
            room = "303";
        }
        else if(roll>=11782&&roll<=11846)
        {
            room = "304";
        }
        else if(roll>=11847&&roll<=11911)
        {
            room = "305";
        }
        else if(roll>=11912&&roll<=11976)
        {
            room = "306";
        }
        else if(roll>=11977&&roll<=12041)
        {
            room = "401";
        }
        else if(roll>=12042&&roll<=12106)
        {
            room = "403";
        }
        else if(roll>=12107&&roll<=12171)
        {
            room = "404";
        }
        else if(roll>=12172&&roll<=12266)
        {
            room = "Admin Building- 1";
        }
         else if(roll>=12267&&roll<=12361)
        {
            room = "Admin Building- 2";
        }
         else if(roll>=12362&&roll<=12476)
        {
            room = "room-112,";
        }
         else if(roll>=12477&&roll<=12536)
        {
            room = "room-201";
        }
         else if(roll>=12537&&roll<=12596)
        {
            room = "room-301";
        }
         else if(roll>=12597&&roll<=12681)
        {
            room = "room-304";
        }
         else if(roll>=12682&&roll<=12766)
        {
            room = "room-401";
        }
         else if(roll>=12767&&roll<=12851)
        {
            room = "room-404";
        }
         else if(roll>=12852&&roll<=12909)
        {
            room = "room-105";
        }
         else if(roll>=12910&&roll<=12967)
        {
            room = "room-106";
        }
         else if(roll>=12968&&roll<=13027)
        {
            room = "room-107";
        }
         else if(roll>=13028&&roll<=13087)
        {
            room = "room-108";
        }
         else if(roll>=13088&&roll<=13127)
        {
            room = "room-501";
        }
         else if(roll>=13128&&roll<=13167)
        {
            room = "room-502";
        }
         else if(roll>=13168&&roll<=13207)
        {
            room = "room-601";
        }
         else if(roll>=13208&&roll<=13247)
        {
            room = "room-602";
        }
         else if(roll>=13248&&roll<=13342)
        {
            room = "room-701";
        }
         else if(roll>=13343&&roll<=13437)
        {
            room = "room-801";
        }
         else if(roll>=13438&&roll<=13477)
        {
            room = "room-802";
        }
         else if(roll>=13478&&roll<=13545)
        {
            room = "101";
        }
         else if(roll>=13546&&roll<=13590)
        {
            room = "102";
        }
         else if(roll>=13591&&roll<=13658)
        {
            room = "103";
        }
         else if(roll>=13659&&roll<=13726)
        {
            room = "104";
        }
         else if(roll>=13727&&roll<=13801)
        {
            room = "105";
        }
         else if(roll>=13802&&roll<=13836)
        {
            room = "106";
        }
         else if(roll>=13837&&roll<=13871)
        {
            room = "107";
        }
         else if(roll>=13872&&roll<=13906)
        {
            room = "208";
        }
         else if(roll>=13907&&roll<=13941)
        {
            room = "209";
        }
         else if(roll>=13942&&roll<=14026)
        {
            room = "06";
        }
         else if(roll>=14027&&roll<=14111)
        {
            room = "07";
        }
         else if(roll>=14112&&roll<=14236)
        {
            room = "08";
        }
         else if(roll>=14237&&roll<=14298)
        {
            room = "09";
        }
         else if(roll>=14299&&roll<=14423)
        {
            room = "10";
        }
         else if(roll>=14424&&roll<=14485)
        {
            room = "20";
        }
         else if(roll>=14486&&roll<=14547)
        {
            room = "21";
        }
         else if(roll>=14548&&roll<=14609)
        {
            room = "204";
        }
         else if(roll>=14610&&roll<=14749)
        {
            room = "205";
        }
         else if(roll>=14750&&roll<=14811)
        {
            room = "304";
        }
         else if(roll>=14812&&roll<=14873)
        {
            room = "305";
        }
         else if(roll>=14874&&roll<=14958)
        {
            room = "ICT Room";
        }
         else if(roll>=14959&&roll<=15119)
        {
            room = "16";
        }
         else if(roll>=15120&&roll<=15288)
        {
            room = "17";
        }
         else if(roll>=15289&&roll<=15377)
        {
            room = "18";
        }
         else if(roll>=15378&&roll<=15465)
        {
            room = "19";
        }
         else if(roll>=15467&&roll<=15500)
        {
            room = "Hall Room";
        }


        return room;
    }
    String findFBuilding(int roll) {
        String building = "";
        if(roll>=1&&roll<=1100){
            building = "Administrative Building";
        }
        else if(roll>=1101&&roll<=2600){
            building = "Academic Building";
        }
        else if(roll>=2601&&roll<=5841){
            building = "Academic Building (New)";
        }
        else if(roll>=5842&&roll<=6181){
            building = "Library";
        }
        else if(roll>=6182&&roll<=6731){
            building = "University Garage";
        }
        else if(roll>=6732&&roll<=7141){
            building = "Banganadhu School and College(Tin Shed 1: Near Library)";
        }
        else if(roll>=7142&&roll<=7461){
            building = "Banganadhu School and College(Tin Shed 2: Near Library)";
        }
        else if(roll>=7462&&roll<=8201){
            building = "Banganadhu School and College(Near VC Residence)";
        }
        else if(roll>=12172&&roll<=12361){
            building = "4th Floor";
        }
else if(roll>=12362&&roll<=12851){
            building = "Science Building";
        }
else if(roll>=12852&&roll<=13087){
            building = "Arts Building";
        }
else if(roll>=13088&&roll<=13477){
            building = "Honours Building";
        }
else if(roll>=13942&&roll<=14236){
            building = "Luthfor Rahman Bhabon";
        }
else if(roll>=14237&&roll<=14423){
            building = "Sabura Rahman Bhaban";
        }
else if(roll>=14424&&roll<=14547){
            building = "Elias Rahman Bhabon";
        }
else if(roll>=14548&&roll<=14609){
            building = "Sobura Rahman Bhabon";
        }
else if(roll>=14610&&roll<=14873){
            building = "Sabura Rahman Bhaban";
        }
else if(roll>=14874&&roll<=14958){
            building = "Elias Rahman Bhaban";
        }
else if(roll>=14959&&roll<=15465){
            building = "Banijya Rahman Bhaban";
        }

        return building;
    }
}